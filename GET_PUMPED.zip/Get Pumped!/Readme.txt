**GET PUMPED!**

Is a game made by Team Danger for the 2013 Pittsburgh Game Jam. We won judge's choice award!

This is a slimmed down singleplayer only version of the game. To run it, you will need a windows operating system, a graphics card, and a screen resolution greater than or equal to 1366 x 768. 

Simply double-click setup.exe to install.

To play the game:
W - Moves the player up
A - Moves the player left
S - Moves the player down
D - Moves the player right
Space - Charges the defibrilator

The goal is to get all of the dead/dying people in the city to your hospital, and keep your opponent from doing the same. Get near a sick person, hold space until the white bar is longer than the red bar at the top of the screen, and release to send people flying! The longer you charge your defibrilator, the further they'll fly!

CREDITS:
Chris Reid - Design / Testing / Gameplay
Luke Davis - Music / Sounds
Wilson Pei - Art
Aaron (Sanchez) Yuan - Programming
Bruce Hill - Programming
Steve Blessing - Programming
Matthew Klingensmith - Programming